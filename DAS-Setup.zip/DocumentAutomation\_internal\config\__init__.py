"""Config package initialization"""
